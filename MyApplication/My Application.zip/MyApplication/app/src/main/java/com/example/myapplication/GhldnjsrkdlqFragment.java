package com.example.myapplication;

import android.os.Bundle;
import android.view.View;

import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.example.myapplication.databinding.FragmentRegistration2Binding;

public class GhldnjsrkdlqFragment extends Fragment {

    private FragmentRegistration2Binding binding;

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = FragmentRegistration2Binding.inflate(getLayoutInflater());

        binding.finish.setOnClickListener(view->{
            ((MainActivity) requireActivity()).moveTo(new LoginFragment());
        });
        binding.getRoot();
    }
}
